import { supabase } from '../utils/supabaseClient';

export async function getServerSideProps() {
  const { data } = await supabase.from('casts').select('username, fid');

  const counts = data.reduce((acc, { username }) => {
    acc[username] = (acc[username] || 0) + 1;
    return acc;
  }, {});

  const sorted = Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .map(([user, count]) => ({ user, count }));

  return { props: { sorted } };
}

export default function Leaderboard({ sorted }) {
  return (
    <div style={{ fontFamily: 'monospace', padding: '2rem' }}>
      <h1>🏆 Cast to Earn Leaderboard</h1>
      <ol>
        {sorted.map(({ user, count }) => (
          <li key={user}>
            @{user} — {count} casts
          </li>
        ))}
      </ol>
    </div>
  );
}