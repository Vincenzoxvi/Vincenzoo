import { supabase } from '../../utils/supabaseClient';

export default async function handler(req, res) {
  const { untrustedData } = req.body;
  const fid = untrustedData?.fid;
  const username = untrustedData?.cast?.author?.username;
  const timestamp = new Date().toISOString();

  await supabase.from('casts').insert([{ fid, username, timestamp }]);

  return res.status(200).json({
    image: "https://your-vercel-url.vercel.app/cast-success.jpg",
    buttons: [
      { label: "Cast Again" },
      { label: "View Leaderboard", action: "link", target: "https://your-vercel-url.vercel.app/leaderboard" }
    ],
    post_url: "https://your-vercel-url.vercel.app/api/frame-join"
  });
}